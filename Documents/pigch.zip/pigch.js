// set variables for current score, total score, current player. with initialise
// rolling dices
// holding button
// new game
var scores, currentScores, activePlayer, isPlaying ;
inIt();
//rock and roll
document.querySelector('.btn-roll').addEventListener('click' , function(){
   if(isPlaying){
 // dice image change according to random number
 var dice1 = Math.floor(Math.random() * 6) + 1;
 var dice2 = Math.floor(Math.random() * 6) + 1;
 document.querySelector('#dice-1').style.display = 'block';
 document.querySelector('#dice-2').style.display = 'block';
 document.querySelector('#dice-1').src = 'dice-' + dice1 + '.png';
 document.querySelector('#dice-2').src = 'dice-' + dice2 + '.png';

 // total numbers added to current score if twoo are not sixes
 if (dice1 + dice2 > 11){
      //next player
     next();
    }else{
    currentScores += (dice1 + dice2) ;
    document.querySelector('#current-' + activePlayer).textContent = currentScores;  
 }    
   }
  
})
 // for button hold
 document.querySelector('.btn-hold').addEventListener('click', function(){
    if(isPlaying){
    //print the total score on UI
    scores[activePlayer] += currentScores;
    document.querySelector('#score-' + activePlayer).textContent = scores[activePlayer] ;
   //check if player wins 
   if( scores[activePlayer] >= 50){
      document.querySelector('#name-' + activePlayer).textContent = 'WINNER !!'
      document.querySelector('.player-'+ activePlayer + '-panel').classList.remove('active');
      document.querySelector('.player-' + activePlayer + '-panel').classList.add('winner');

      document.querySelector('#dice-1').style.display = 'none';
      document.querySelector('#dice-2').style.display = 'none';
      isPlaying = false;
      
   }else{
      next();
   }
   // next player
    }

})

// for new game
document.querySelector('.btn-new').addEventListener('click' , inIt);
 
function next(){
   currentScores = 0
   document.querySelector('#current-'+ activePlayer).textContent = '0';
   activePlayer === 0 ? activePlayer = 1 : activePlayer = 0 ;
   document.querySelector('.player-0-panel').classList.toggle('active');
   document.querySelector('.player-1-panel').classList.toggle('active');
   document.querySelector('#dice-1').style.display = 'none';
   document.querySelector('#dice-2').style.display = 'none';

}

function inIt(){
   scores = [0,0];
   activePlayer = 0;
   currentScores = 0;
   isPlaying = true;
   // making all the values 0 to start a game
   document.querySelector('#score-0').textContent = '0';
   document.querySelector('#current-0').textContent = '0';
   document.querySelector('#score-1').textContent = '0';
   document.querySelector('#current-1').textContent = '0';
   document.querySelector('#dice-1').style.display = 'none';
   document.querySelector('#dice-2').style.display = 'none';
   document.querySelector('#name-0').textContent = 'Player 1';
   document.querySelector('#name-1').textContent = 'Player 2'
   document.querySelector('.player-0-panel').classList.remove('winner');
   document.querySelector('.player-0-panel').classList.add('active');
   document.querySelector('.player-1-panel').classList.remove('winner');
   
}